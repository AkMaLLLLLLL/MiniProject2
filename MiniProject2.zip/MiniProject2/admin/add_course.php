<?php
require_once "../config/db.php";
require_once "../includes/auth.php";
requireAdmin();

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $course_code = trim($_POST['course_code']);
    $course_name = trim($_POST['course_name']);
    $credit_hour = trim($_POST['credit_hour']);

    if ($course_code === "" || $course_name === "" || $credit_hour === "") {
        $message = "All fields are required.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO courses (course_code, course_name, credit_hour) VALUES (?, ?, ?)");
        $stmt->execute([$course_code, $course_name, $credit_hour]);
        header("Location: courses.php");
        exit;
    }
}

include "../includes/header.php";
?>

<h3>Add Course</h3>

<?php if ($message): ?>
<div class="alert alert-danger"><?= $message ?></div>
<?php endif; ?>

<form method="POST">
    <div class="mb-3">
        <label>Course Code</label>
        <input type="text" name="course_code" class="form-control">
    </div>

    <div class="mb-3">
        <label>Course Name</label>
        <input type="text" name="course_name" class="form-control">
    </div>

    <div class="mb-3">
        <label>Credit Hour</label>
        <input type="number" name="credit_hour" class="form-control">
    </div>

    <button type="submit" class="btn btn-success">Add</button>
    <a href="courses.php" class="btn btn-secondary">Back</a>
</form>

<?php include "../includes/footer.php"; ?>