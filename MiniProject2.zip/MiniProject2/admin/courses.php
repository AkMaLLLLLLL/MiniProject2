<?php
require_once "../config/db.php";
require_once "../includes/auth.php";
requireAdmin();

$stmt = $pdo->query("SELECT * FROM courses ORDER BY id DESC");
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

include "../includes/header.php";
?>

<h3>Manage Courses</h3>
<a href="add_course.php" class="btn btn-success mb-3">Add Course</a>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Course Code</th>
            <th>Course Name</th>
            <th>Credit Hour</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($courses as $course): ?>
        <tr>
            <td><?= $course['id'] ?></td>
            <td><?= htmlspecialchars($course['course_code']) ?></td>
            <td><?= htmlspecialchars($course['course_name']) ?></td>
            <td><?= htmlspecialchars($course['credit_hour']) ?></td>
            <td>
                <a href="edit_course.php?id=<?= $course['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                <a href="delete_course.php?id=<?= $course['id'] ?>" class="btn btn-danger btn-sm"
                   onclick="return confirm('Delete this course?')">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include "../includes/footer.php"; ?>