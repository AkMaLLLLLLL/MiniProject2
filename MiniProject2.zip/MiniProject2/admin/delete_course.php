<?php
require_once "../config/db.php";
require_once "../includes/auth.php";
requireAdmin();

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    $stmt = $pdo->prepare("DELETE FROM courses WHERE id = ?");
    $stmt->execute([$id]);
}

header("Location: courses.php");
exit;
?>