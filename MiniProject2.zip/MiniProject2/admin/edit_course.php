<?php
require_once "../config/db.php";
require_once "../includes/auth.php";
requireAdmin();

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid course ID.");
}

$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM courses WHERE id = ?");
$stmt->execute([$id]);
$course = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$course) {
    die("Course not found.");
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $course_code = trim($_POST['course_code']);
    $course_name = trim($_POST['course_name']);
    $credit_hour = trim($_POST['credit_hour']);

    if ($course_code === "" || $course_name === "" || $credit_hour === "") {
        $message = "All fields are required.";
    } else {
        $update = $pdo->prepare("UPDATE courses SET course_code = ?, course_name = ?, credit_hour = ? WHERE id = ?");
        $update->execute([$course_code, $course_name, $credit_hour, $id]);
        header("Location: courses.php");
        exit;
    }
}

include "../includes/header.php";
?>

<h3>Edit Course</h3>

<?php if ($message): ?>
<div class="alert alert-danger"><?= $message ?></div>
<?php endif; ?>

<form method="POST">
    <div class="mb-3">
        <label>Course Code</label>
        <input type="text" name="course_code" class="form-control" value="<?= htmlspecialchars($course['course_code']) ?>">
    </div>

    <div class="mb-3">
        <label>Course Name</label>
        <input type="text" name="course_name" class="form-control" value="<?= htmlspecialchars($course['course_name']) ?>">
    </div>

    <div class="mb-3">
        <label>Credit Hour</label>
        <input type="number" name="credit_hour" class="form-control" value="<?= htmlspecialchars($course['credit_hour']) ?>">
    </div>

    <button type="submit" class="btn btn-warning">Update</button>
    <a href="courses.php" class="btn btn-secondary">Back</a>
</form>

<?php include "../includes/footer.php"; ?>