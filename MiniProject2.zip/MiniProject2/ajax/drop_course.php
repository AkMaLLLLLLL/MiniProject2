<?php
require_once "../config/db.php";
require_once "../includes/auth.php";
requireStudent();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $reg_id = $_POST['reg_id'] ?? '';
    $user_id = $_SESSION['user_id'];

    if (!is_numeric($reg_id)) {
        exit("Invalid registration.");
    }

    $stmt = $pdo->prepare("DELETE FROM registrations WHERE id = ? AND user_id = ?");
    $stmt->execute([$reg_id, $user_id]);

    echo "Course dropped successfully.";
}
?>