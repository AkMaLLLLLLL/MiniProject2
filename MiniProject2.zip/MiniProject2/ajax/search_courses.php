<?php
require_once "../config/db.php";
require_once "../includes/auth.php";
requireStudent();

$keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';

$sql = "SELECT * FROM courses WHERE course_code LIKE ? OR course_name LIKE ? ORDER BY id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute(["%$keyword%", "%$keyword%"]);
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($courses) {
    echo '<table class="table table-bordered">';
    echo '<thead>
            <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Credit Hour</th>
                <th>Action</th>
            </tr>
          </thead>';
    echo '<tbody>';

    foreach ($courses as $course) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($course['course_code']) . '</td>';
        echo '<td>' . htmlspecialchars($course['course_name']) . '</td>';
        echo '<td>' . htmlspecialchars($course['credit_hour']) . '</td>';
        echo '<td><button type="button" class="btn btn-primary btn-sm register-course" data-id="' . $course['id'] . '">Register</button></td>';
        echo '</tr>';
    }

    echo '</tbody></table>';
} else {
    echo '<div class="alert alert-warning">No courses found.</div>';
}
?>