<?php
require_once "../config/db.php";
require_once "../includes/auth.php";
requireStudent();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_SESSION['user_id'];
    $course_id = $_POST['course_id'] ?? '';

    if (!is_numeric($course_id)) {
        exit("Invalid course.");
    }

    $check = $pdo->prepare("SELECT id FROM registrations WHERE user_id = ? AND course_id = ?");
    $check->execute([$user_id, $course_id]);

    if ($check->rowCount() > 0) {
        exit("You already registered this course.");
    }

    $stmt = $pdo->prepare("INSERT INTO registrations (user_id, course_id) VALUES (?, ?)");
    $stmt->execute([$user_id, $course_id]);

    echo "Course registered successfully.";
}
?>