<?php
require_once "includes/auth.php";
requireLogin();
include "includes/header.php";
?>

<h3>Dashboard</h3>

<?php if ($_SESSION['role'] === 'admin'): ?>
    <div class="list-group">
        <a href="admin/courses.php" class="list-group-item list-group-item-action">Manage Courses</a>
    </div>
<?php else: ?>
    <div class="list-group">
        <a href="student/courses.php" class="list-group-item list-group-item-action">Register Courses</a>
        <a href="student/my_courses.php" class="list-group-item list-group-item-action">My Registered Courses</a>
    </div>
<?php endif; ?>

<?php include "includes/footer.php"; ?>