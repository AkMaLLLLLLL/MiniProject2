<?php
require_once "../config/db.php";
require_once "../includes/auth.php";
requireStudent();

$user_id = $_SESSION['user_id'];

$sql = "SELECT registrations.id AS reg_id, courses.course_code, courses.course_name, courses.credit_hour
        FROM registrations
        INNER JOIN courses ON registrations.course_id = courses.id
        WHERE registrations.user_id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id]);
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

include "../includes/header.php";
?>

<a href="../dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>

<h3>My Registered Courses</h3>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Course Code</th>
            <th>Course Name</th>
            <th>Credit Hour</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody id="myCourseTable">
        <?php foreach ($courses as $course): ?>
        <tr id="row-<?= $course['reg_id'] ?>">
            <td><?= htmlspecialchars($course['course_code']) ?></td>
            <td><?= htmlspecialchars($course['course_name']) ?></td>
            <td><?= htmlspecialchars($course['credit_hour']) ?></td>
            <td>
                <button class="btn btn-danger btn-sm drop-course" data-id="<?= $course['reg_id'] ?>">Drop</button>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<script>
document.addEventListener('click', function (e) {
    if (e.target.classList.contains('drop-course')) {
        const regId = e.target.getAttribute('data-id');

        if (confirm('Are you sure to drop this course?')) {
            fetch('../ajax/drop_course.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'reg_id=' + encodeURIComponent(regId)
            })
            .then(response => response.text())
            .then(data => {
                alert(data);
                const row = document.getElementById('row-' + regId);
                if (row) {
                    row.remove();
                }
            })
            .catch(error => {
                alert('Drop failed');
                console.error(error);
            });
        }
    }
});
</script>

<?php include "../includes/footer.php"; ?>