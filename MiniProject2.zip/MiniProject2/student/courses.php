<?php
require_once "../includes/auth.php";
requireStudent();
include "../includes/header.php";
?>

<a href="../dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>

<h3>Available Courses</h3>

<div class="mb-3">
    <input type="text" id="search" class="form-control" placeholder="Search course by code or name...">
</div>

<div id="courseList"></div>

<script>
function loadCourses(keyword = '') {
    fetch('../ajax/search_courses.php?keyword=' + encodeURIComponent(keyword))
        .then(response => response.text())
        .then(data => {
            document.getElementById('courseList').innerHTML = data;
        })
        .catch(error => {
            document.getElementById('courseList').innerHTML =
                "<div class='alert alert-danger'>Error loading courses</div>";
            console.error(error);
        });
}

document.addEventListener('DOMContentLoaded', function () {
    loadCourses();

    document.getElementById('search').addEventListener('keyup', function () {
        loadCourses(this.value);
    });

    document.addEventListener('click', function (e) {
        if (e.target.classList.contains('register-course')) {
            const courseId = e.target.getAttribute('data-id');

            fetch('../ajax/register_course.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'course_id=' + encodeURIComponent(courseId)
            })
            .then(response => response.text())
            .then(data => {
                alert(data);
                loadCourses(document.getElementById('search').value);
            })
            .catch(error => {
                alert('Register failed');
                console.error(error);
            });
        }
    });
});
</script>

<?php include "../includes/footer.php"; ?>