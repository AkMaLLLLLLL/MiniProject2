<?php
require_once "config/db.php";
session_start();

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role = "student";

    if (empty($username) || empty($password)) {
        $message = "Please fill in all fields.";
    } else {
        $check = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $check->execute([$username]);

        if ($check->rowCount() > 0) {
            $message = "Username already exists.";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
            $stmt->execute([$username, $hashedPassword, $role]);
            $message = "Registration successful. <a href='login.php'>Login here</a>.";
        }
    }
}
?>

<?php include "includes/header.php"; ?>

<div class="row justify-content-center">
    <div class="col-md-5">
        <h3>Register</h3>

        <?php if ($message): ?>
            <div class="alert alert-info"><?= $message ?></div>
        <?php endif; ?>

        <form method="POST" id="registerForm">
            <div class="mb-3">
                <label>Username</label>
                <input type="text" name="username" id="username" class="form-control">
                <small class="text-danger" id="usernameError"></small>
            </div>

            <div class="mb-3">
                <label>Password</label>
                <input type="password" name="password" id="password" class="form-control">
                <small class="text-danger" id="passwordError"></small>
            </div>

            <button type="submit" class="btn btn-primary">Register</button>
            <a href="login.php" class="btn btn-secondary">Login</a>
        </form>
    </div>
</div>

<script>
document.getElementById("registerForm").addEventListener("submit", function(e) {
    let valid = true;
    document.getElementById("usernameError").textContent = "";
    document.getElementById("passwordError").textContent = "";

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    if (username === "") {
        document.getElementById("usernameError").textContent = "Username is required";
        valid = false;
    }

    if (password.length < 6) {
        document.getElementById("passwordError").textContent = "Password must be at least 6 characters";
        valid = false;
    }

    if (!valid) e.preventDefault();
});
</script>

<?php include "includes/footer.php"; ?>