<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PCRS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-dark bg-dark navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="/MiniProject2_Group/dashboard.php">Polytechnic Course Registration System (PCRS)</a>
        <div>
            <?php if (isset($_SESSION['user_id'])): ?>
                <span class="text-white me-3">
                    <?= htmlspecialchars($_SESSION['username']) ?> (<?= htmlspecialchars($_SESSION['role']) ?>)
                </span>
                <a href="/MiniProject2/logout.php" class="btn btn-light btn-sm">Logout</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<div class="container mt-4">