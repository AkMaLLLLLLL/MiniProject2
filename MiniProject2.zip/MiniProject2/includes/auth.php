<?php
session_start();

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: /MiniProject2_Group/login.php");
        exit;
    }
}

function requireAdmin() {
    requireLogin();
    if ($_SESSION['role'] !== 'admin') {
        header("Location: /MiniProject2_Group/dashboard.php");
        exit;
    }
}

function requireStudent() {
    requireLogin();
    if ($_SESSION['role'] !== 'student') {
        header("Location: /MiniProject2/dashboard.php");
        exit;
    }
}
?>